"""Inference and evaluation
"""