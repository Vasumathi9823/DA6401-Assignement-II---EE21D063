"""Training entrypoint
"""